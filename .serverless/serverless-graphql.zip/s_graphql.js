
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'from81',
  applicationName: 'anu-graphql',
  appUid: '3R6Z9KrMRlt3WfJzMY',
  orgUid: '74e86231-aa87-47ef-b3aa-03b6c829b6b3',
  deploymentUid: 'f198ab6f-51e6-477e-be12-e758ac6470e8',
  serviceName: 'serverless-graphql',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-graphql-dev-graphql', timeout: 6 };

try {
  const userHandler = require('./.src/graphql.js');
  module.exports.handler = serverlessSDK.handler(userHandler.graphqlHandler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}