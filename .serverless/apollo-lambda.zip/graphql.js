// This module can be used to serve the GraphQL endpoint
// as a lambda function

const { ApolloServer, gql } = require('apollo-server-lambda')
const dotenv = require('dotenv')
const { Neo4jGraphQL } = require('@neo4j/graphql')
const neo4j = require('neo4j-driver')

// set environment variables from .env
dotenv.config()

/*
 * Check for GRAPHQL_SCHEMA environment variable to specify schema file
 * fallback to schema.graphql if GRAPHQL_SCHEMA environment variable is not set
 */

// Construct a schema, using GraphQL schema language
const typeDefs = gql`
  type Course {
    id: ID
    name: String
    subject_code: String
    course_number: Int
    units: Int
    description: String
    subject: String
    college: String
    offered_by: String
    academic_career: String
    co_taught: String
    prerequisites_raw: String
    prerequisites: [Course]
      @relationship(
        type: "PREREQUISITE"
        properties: "Prerequisite"
        direction: OUT
      )
    unlocks: [Course]
      @relationship(
        type: "PREREQUISITE"
        properties: "Prerequisite"
        direction: IN
      )
  }

  type Requirement {
    units: Int
    description: String
    requirements: [Requirement]
      @relationship(type: "REQUIREMENT", direction: OUT)
    classes: [Course] @relationship(type: "REQUIREMENT", direction: OUT)
    specialisations: [Specialisation]
      @relationship(type: "REQUIREMENT", direction: OUT)
  }

  type Specialisation {
    id: ID
    name: String
    type: String
    units: Int
    requirements: [Requirement]
      @relationship(type: "REQUIREMENT", direction: OUT)
    classes: [Course]
      @cypher(statement: "MATCH (this)-[:REQUIREMENT*..5]->(s:Course) RETURN s")
  }

  type Program {
    id: ID
    name: String
    units: Int
    requirements: [Requirement]
      @relationship(type: "REQUIREMENT", direction: OUT)
    specialisations: [Specialisation]
      @cypher(statement: "MATCH (this)-[*..5]->(s:Specialisation) RETURN s")
  }
`

const driver = neo4j.driver(
  process.env.NEO4J_URI || 'bolt://localhost:7687',
  neo4j.auth.basic(
    process.env.NEO4J_USER || 'neo4j',
    process.env.NEO4J_PASSWORD || 'neo4j'
  )
)

const neoSchema = new Neo4jGraphQL({ typeDefs, driver })

const server = new ApolloServer({
  schema: neoSchema.schema,
  context: { driver, neo4jDatabase: process.env.NEO4J_DATABASE },
})

exports.handler = server.createHandler()
